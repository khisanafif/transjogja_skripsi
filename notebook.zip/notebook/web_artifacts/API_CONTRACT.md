# Web/Backend Artifacts - Trans Jogja Tourism Recommendation

## Core
- web_artifacts/poi_catalog.json
- web_artifacts/stops.json
- web_artifacts/stop_routes.json
- web_artifacts/stop_board_departures.csv
- web_artifacts/routes_geojson_by_route_id.json

## Coverage
- final web POI hanya berisi destinasi dengan halte terdekat <= 1200 m
- report/poi_catalog_all_audit.csv menyimpan semua POI awal
- report/excluded_pois_out_of_coverage.csv menyimpan POI yang di-hard reset

## Recommendation
- web_artifacts/recommendation_origin_stops.csv
- web_artifacts/recommendation_examples.json
- model/recommendation_model_settings.json

## Rumus ETA_total
ETA_total = waktu_tunggu + sum(waktu_segmen) + penalti_transit + waktu_jalan_kaki_akhir

## Walking access
- 0-400 m: optimal
- 400-800 m: moderate
- 800-1200 m: extended dengan penalti
- >1200 m: out of coverage