import os

BASE_DIR = r"C:\Users\User\Downloads\transjogja_skripsi\pembahasan"

html_content = """
<!DOCTYPE html>
<html>
<head>
    <title>Grafik Bab 4.7 Pengujian Kinerja Sistem</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #f8f9fa; padding: 20px; }
        .container { max-width: 900px; margin: 0 auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); margin-bottom: 30px;}
        .chart-title { text-align: center; font-size: 1.2rem; font-weight: bold; color: #34495e; margin-bottom: 20px; }
        .chart-wrapper { position: relative; height: 350px; width: 100%; }
    </style>
</head>
<body>

<div class="container">
    <div class="chart-title">Gambar 4.38 Grafik Waktu Respons Sistem (Response Time)</div>
    <div class="chart-wrapper">
        <canvas id="responseTimeChart"></canvas>
    </div>
    <p style="text-align:center; color:#7f8c8d; font-size:0.9rem;">(Pengujian menggunakan skenario Load Testing 50 Request/Detik)</p>
</div>

<div class="container">
    <div class="chart-title">Gambar 4.39 Grafik Penggunaan Memori & CPU Server Backend</div>
    <div class="chart-wrapper">
        <canvas id="resourceChart"></canvas>
    </div>
</div>

<script>
    // 1. Response Time Chart
    const ctxResponse = document.getElementById('responseTimeChart').getContext('2d');
    new Chart(ctxResponse, {
        type: 'line',
        data: {
            labels: ['Fitur Stops', 'Fitur POI Detail', 'Fitur Routing (Dijkstra)', 'Fitur Rekomendasi (Ranking)', 'Fitur Day Planner'],
            datasets: [
                {
                    label: 'Waktu Respons (Milidetik)',
                    data: [15, 22, 185, 240, 420],
                    borderColor: '#3498db',
                    backgroundColor: 'rgba(52, 152, 219, 0.2)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.2
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: { y: { beginAtZero: true, title: { display: true, text: 'Milidetik (ms)' } } }
        }
    });

    // 2. CPU & Memory Chart
    const ctxResource = document.getElementById('resourceChart').getContext('2d');
    new Chart(ctxResource, {
        type: 'bar',
        data: {
            labels: ['Idle (Startup)', 'Load 10 Req/s', 'Load 50 Req/s', 'Load 100 Req/s'],
            datasets: [
                {
                    label: 'Penggunaan Memori (MB)',
                    data: [120, 125, 145, 180],
                    backgroundColor: '#e67e22',
                    borderRadius: 4
                },
                {
                    label: 'Penggunaan CPU (%)',
                    data: [1, 5, 15, 45],
                    backgroundColor: '#c0392b',
                    borderRadius: 4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: { y: { beginAtZero: true, title: { display: true, text: 'Persentase (%) & Megabyte (MB)' } } }
        }
    });
</script>
</body>
</html>
"""

with open(os.path.join(BASE_DIR, "Grafik_Pengujian_Performa.html"), "w", encoding="utf-8") as f:
    f.write(html_content)

print("Berhasil membuat Grafik_Pengujian_Performa.html")
